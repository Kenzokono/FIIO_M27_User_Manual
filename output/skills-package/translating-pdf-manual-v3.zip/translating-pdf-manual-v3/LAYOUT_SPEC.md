# LAYOUT_SPEC.md — v2 レイアウト仕様書

Phase 3 で適用する v2 レイアウト改善の仕様。v1 の基本的な HTML 構造を維持しつつ、モダンな CSS デザイン・レスポンシブ対応・アクセシビリティ向上を実現する。

---

## 1. Google Fonts

`<head>` 内に以下を追加し、Inter（英数字・見出し用）と Noto Sans JP（日本語本文用）を読み込む。

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+JP:wght@400;500;600;700&display=swap" rel="stylesheet">
```

**フォント使い分け:**
- 見出し（h1〜h4）: `'Inter', 'Noto Sans JP', sans-serif`
- 本文: `'Noto Sans JP', 'Inter', sans-serif`

---

## 2. Figure Classification（画像分類）

`image-map.json` の各画像の寸法情報に基づき、`<figure>` 要素に適切な CSS クラスを付与する。

| クラス名 | 判定基準 | max-width | 備考 |
|---|---|---|---|
| `fig-cover` | 最初の画像で、正方形またはほぼ正方形（アスペクト比 0.8〜1.2） | 480px | 製品カバー画像 |
| `fig-hardware` | ラベル付き図面（`context_hint` に "diagram", "parts", "guide" を含む） | 620px | 各部名称図・接続図 |
| `fig-phone` | 縦長画像（`height > width * 1.5`） | 360px | スマホ・DAP の UI スクリーンショット |
| `fig-desktop` | 横長画像（`width > height`）で上記に該当しない | 600px | 横向きスクリーンショット・設定画面 |

### 分類ロジック（優先順位）

1. 最初の画像 → アスペクト比チェック → `fig-cover`
2. `context_hint` に diagram / parts / guide を含む → `fig-hardware`
3. `height > width * 1.5` → `fig-phone`
4. `width > height` → `fig-desktop`
5. いずれにも該当しない → クラスなし（デフォルトスタイル適用）

### 例外

- `.image-grid` 内の画像は既存の `image-grid-item` クラスを維持し、上記の分類クラスは付与しない。

---

## 3. CSS 仕様

v1 の基本 CSS を完全に置き換える v2 モダン CSS。`templates/style.css` に定義。

### 主な変更点

| 項目 | v1 | v2 |
|---|---|---|
| フォント | system-ui | Noto Sans JP + Inter (Google Fonts) |
| 行間 | 1.6 | 1.8 |
| 背景色 | #fff | #fafafa |
| 最大幅 | 900px | 880px |
| h2 装飾 | `border-bottom` 下線 | `border-left: 4px solid #2563eb` 左アクセントバー |
| セクション番号 | 手動 | CSS counter による自動採番 |
| 目次 | 基本リスト | カード風（白背景・box-shadow・`columns: 2`） |
| テーブル | 基本罫線 | `border-radius: 8px` ラッパー + hover エフェクト |
| 警告ボックス | テキストのみ | `::before` 擬似要素によるアイコン（⛔ ⚠️ ℹ️） |
| notice ボックス | 黄色系 | 青色 `#f0f9ff` |
| figcaption | `font-style: italic` | `font-style: normal`（日本語テキスト対応） |
| トップに戻るボタン | なし | 固定ボタン（右下） |
| レスポンシブ | なし | 768px + 640px ブレークポイント |
| 印刷スタイル | 基本 | TOC 非表示・hover 無効化・最適化 |

### 警告ボックスのアイコンマッピング

| クラス | アイコン | 背景色 | ボーダー色 |
|---|---|---|---|
| `.warning-danger` | ⛔ | 赤系 | 赤 |
| `.warning-caution` | ⚠️ | オレンジ系 | オレンジ |
| `.warning-notice` | ℹ️ | 青系 `#f0f9ff` | 青 |

---

## 4. Back-to-Top ボタン

`</body>` の直前に以下を挿入する。

### HTML

```html
<a href="#" id="back-to-top" aria-label="ページの先頭に戻る" title="トップに戻る">&#8593;</a>
```

### JavaScript

```html
<script>
(function() {
    var btn = document.getElementById('back-to-top');
    if (!btn) return;
    window.addEventListener('scroll', function() {
        if (window.scrollY > 600) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    }, { passive: true });
})();
</script>
```

### CSS（style.css に含む）

- 右下に固定配置（`position: fixed; bottom: 2rem; right: 2rem`）
- 青色の円形ボタン
- デフォルトは非表示（`opacity: 0; pointer-events: none`）
- `.visible` クラスで表示（`opacity: 1; pointer-events: auto`）
- トランジション付き

---

## 5. チェックリスト

Phase 3 実行時の確認事項:

- [ ] Google Fonts リンクが `<head>` に挿入されている
- [ ] 全 `<figure>` に適切な分類クラスが付与されている
- [ ] `.image-grid` 内の画像は `image-grid-item` を維持している
- [ ] `style.css` が v2 版に置き換わっている
- [ ] Back-to-Top ボタンの HTML + JS が挿入されている
- [ ] 768px / 640px ブレークポイントで正しくレスポンシブ動作する
- [ ] 印刷プレビューで TOC が非表示になっている
