# HTML Specification

## Section structure from PDF

Determine HTML sections from the PDF source:

1. If PDF has a Table of Contents → adopt that hierarchy directly
2. If no TOC → infer from heading styles (font size, bold weight)
3. Assign each section a unique ID: kebab-case from English heading
   - Example: "Buttons and Ports" → `id="buttons-and-ports"`
4. Build nav#toc linking to every section ID

## HTML template

Use `templates/index.html` as the starting template. Key structure:

```html
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{PRODUCT_NAME} 取扱説明書</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>{PRODUCT_NAME} 取扱説明書</h1>
        <p class="subtitle">Complete User Manual — 日本語版</p>
    </header>

    <nav id="toc">
        <h2>目次</h2>
        <ol>
            <li><a href="#section-id">セクション名</a>
                <ol>
                    <li><a href="#subsection-id">サブセクション名</a></li>
                </ol>
            </li>
        </ol>
    </nav>

    <main>
        <section id="section-id">
            <h2>セクション名</h2>
            <p>翻訳テキスト</p>

            <figure>
                <img src="images/pageX_imgY.png"
                     alt="日本語の説明"
                     loading="lazy">
                <figcaption>日本語キャプション</figcaption>
            </figure>
        </section>
    </main>

    <footer>
        <p>本マニュアルは{PRODUCT_NAME}の英語版マニュアルの日本語訳です。</p>
        <p>画像はすべて参考用です。実際の製品と異なる場合があります。</p>
    </footer>
</body>
</html>
```

## CSS requirements

Use `templates/style.css` as the base. Required features:

**Layout**
- Responsive: mobile-first, max-width: 900px centered
- Sticky TOC: `position: sticky; top: 0` with background and z-index
- Section spacing: adequate margin between sections

**Typography**
- Font stack: `system-ui, -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif`
- Body text: 16px base, 1.7 line-height
- Headings: clear hierarchy with consistent sizing

**Images**
- `max-width: 100%; height: auto` on all images
- `<figure>` centered with margin
- `<figcaption>` styled as caption text (smaller, muted color)

**Tables**
- Bordered, readable
- Horizontal scroll wrapper: `overflow-x: auto` on parent div
- Alternating row colors for readability

**Warning boxes**
- `.warning-danger`: red background (#fef2f2), red left border
- `.warning-caution`: orange background (#fff7ed), orange left border
- `.warning-notice`: yellow background (#fefce8), yellow left border
- Padding, bold label, clear text

**Print styles** (`@media print`)
- Hide nav#toc
- Remove sticky positioning
- Page break control: `break-before: page` on h2
- Images: ensure they don't break across pages

## Image placement rules

### Reading image-map.json

Each entry in `image-map.json`:

```json
{
    "filename": "page3_img1.png",
    "page": 3,
    "rect": {"x0": 72.0, "y0": 150.0, "x1": 540.0, "y1": 400.0},
    "placement_confidence": "high",
    "context_hint": "Front panel labeled diagram",
    "nearby_headings": ["Buttons and Ports", "1. Pictorial Guide"],
    "image_width": 800,
    "image_height": 600,
    "is_decorative": false
}
```

### Placement logic

1. Match `nearby_headings` and `page` to the corresponding HTML section
2. Place the image near the text that describes it (same section, same topic)
3. Use `context_hint` to write appropriate `alt` text and `figcaption`

### Special cases

- `is_decorative: true` → `alt=""`, no figcaption, may be omitted
- `placement_confidence: "low"` → add `data-placement-check="true"` to the figure element
- Images in tables (e.g., port comparison) → use `<td><img>` within table structure
- Multiple screenshots side by side → use CSS flexbox or grid layout
- Grid of theme screenshots → preserve original order from PDF

### Alt text guidelines

- Always in Japanese
- Describe what the image shows, not the filename
- For UI screenshots: describe the screen name and key elements visible
- For diagrams: describe what parts are labeled
- Example: `alt="M27の前面パネル。左からボリュームノブ、3.5mmヘッドホン出力、4.4mmバランス出力"`
