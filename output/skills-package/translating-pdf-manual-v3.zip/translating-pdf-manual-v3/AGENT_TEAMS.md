# Agent Teams Orchestration Guide

Use Agent Teams when the PDF manual exceeds 20 pages. Requires `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`.

## Team structure

5 agents across 5 phases. Strict file ownership prevents overwrite collisions.

| Agent | Phase | Owned files | Dependencies |
|---|---|---|---|
| image-extractor | 1 | {OUTPUT_DIR}/images/*, image-map.json | None |
| translator-html | 2 | {OUTPUT_DIR}/index.html | Waits for image-map.json |
| layout-improver | 3 | {OUTPUT_DIR}/style.css, index.html (class attrs only) | After Phase 2 |
| image-translator | 4 | {OUTPUT_DIR}/images/* (translated only) | After Phase 3 |
| qa-reviewer | 5 | {OUTPUT_DIR}/qa-report.md | After Phase 4 |

File ownership is the most important rule. No agent writes to another agent's files. Reading is allowed.

## Execution flow

```
[Lead] Create team
    │
    ├─→ [image-extractor] Phase 1: Extract images (parallel start)
    │        └── image-map.json complete → message translator-html
    │
    ├─→ [translator-html] Phase 2: Translate + build HTML (parallel start)
    │        ├── Text translation proceeds immediately
    │        ├── Image placement waits for image-map.json message
    │        └── HTML complete → message lead
    │
    └─→ [Lead] Phase 2 done
              │
              ├─→ [layout-improver] Phase 3: Apply v3 layout improvements
              │        ├── Read LAYOUT_SPEC.md for CSS specification
              │        ├── Add Google Fonts link tags to <head>
              │        ├── Add figure classes based on image-map.json dimensions
              │        ├── Replace style.css with modern v3 version
              │        ├── Add back-to-top button + JS
              │        └── Layout complete → message lead
              │
              ├─→ [Lead] Phase 3 done
              │        │
              │        └─→ [image-translator] Phase 4: Translate screenshot text
              │                 ├── Read IMAGE_TRANSLATION.md for specification
              │                 ├── Run translate_images.py per group
              │                 ├── Update <img src> in index.html for translated images
              │                 └── Translation complete → message lead
              │
              └─→ [Lead] Phase 4 done → spawn qa-reviewer (fresh context)
                         └─→ [qa-reviewer] Phase 5: Verify everything
                                  └── qa-report.md complete → message lead
```

## Spawn prompts

Teammates do NOT inherit the lead's conversation history. Each spawn prompt must contain all necessary context.

### image-extractor spawn prompt

```
You are the image-extractor agent. Your task:

1. Install: pip install pymupdf Pillow
2. Run: python scripts/extract_images.py {PDF_FILENAME} {OUTPUT_DIR}
3. Review the generated image-map.json
4. For each image, fill in the context_hint field:
   - What the image shows (e.g., "Front panel diagram with labeled ports")
   - Which PDF section it belongs to (e.g., "Section: Buttons and Ports")
5. Verify all images exist in {OUTPUT_DIR}/images/

File ownership: You may ONLY write to {OUTPUT_DIR}/images/ and {OUTPUT_DIR}/image-map.json

When complete, message translator-html:
"Image extraction complete. image-map.json ready. Total: {N} images, low-confidence: {M}"
```

### translator-html spawn prompt

```
You are the translator-html agent. Your task:

1. Read {PDF_FILENAME} and extract all text
2. Identify section structure from PDF TOC or heading styles
3. Translate English to Japanese following these rules:
   - Style: です・ます (polite form)
   - Product names unchanged: {PRODUCT_NAME}, {BRAND_NAME}
   - Menu paths: English（日本語）format
   - Sentences under 40 characters
   - Active voice preferred
   - Natural Japanese, not machine-translation tone
4. Build responsive HTML: {OUTPUT_DIR}/index.html
5. When you receive image-map.json notification from image-extractor:
   - Read {OUTPUT_DIR}/image-map.json
   - Place images in correct sections using context_hint and nearby_headings
   - Add Japanese alt text and figcaption to every image
   - Mark placement_confidence:"low" images with data-placement-check="true"

Terminology table:
{TERMINOLOGY}

File ownership: You may ONLY write to {OUTPUT_DIR}/index.html
Do NOT create or modify style.css — that is owned by layout-improver in Phase 3.

For HTML template and CSS specs, read HTML_SPEC.md in the skill directory.
For full translation rules, read TRANSLATION_GUIDE.md in the skill directory.

When complete, message lead:
"Translation and HTML build complete. Ready for layout improvement."
```

### layout-improver spawn prompt

```
You are the layout-improver agent. Your task is to apply v3 layout enhancements to the translated HTML manual.

Read LAYOUT_SPEC.md in the skill directory for the FULL CSS specification. Follow it exactly.

Tasks:

1. Add Google Fonts link tags to <head> in {OUTPUT_DIR}/index.html:
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet">

2. Add figure classes based on image dimensions from {OUTPUT_DIR}/image-map.json:
   - Read image-map.json to get image_width and image_height for each image
   - Classify each <figure> element:
     - fig-cover: width >= 700 and aspect ratio > 1.5 (wide cover/hero images)
     - fig-hardware: width >= 500 and height >= 400 (hardware photos/diagrams)
     - fig-phone: width < 400 and height > width * 1.5 (tall phone screenshots)
     - fig-desktop: width >= 600 and height < width (wide UI screenshots)
   - Add the class to the <figure> element (e.g., <figure class="fig-phone">)

3. Replace {OUTPUT_DIR}/style.css with the modern v3 version:
   - Read templates/style.css as the BASE
   - Add Google Fonts font-family declarations (Inter for headings, Noto Sans JP for body)
   - Add figure class sizing rules from LAYOUT_SPEC.md
   - Add CSS counter for automatic section numbering on h2 elements
   - Add back-to-top button styles

4. Add back-to-top button before </body> in index.html:
   <button id="back-to-top" aria-label="トップへ戻る">↑</button>
   <script>
   const btn = document.getElementById('back-to-top');
   window.addEventListener('scroll', () => {
     btn.style.display = window.scrollY > 300 ? 'block' : 'none';
   });
   btn.addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));
   </script>

File ownership: You may ONLY write to {OUTPUT_DIR}/style.css and {OUTPUT_DIR}/index.html (class attributes and <head> tags only — do NOT modify translated text content).

When complete, message lead:
"Layout improvement complete. Google Fonts, figure classes, section counter, and back-to-top button applied."
```

### image-translator spawn prompt

```
You are the image-translator agent. Your task is to translate English text visible in UI screenshots to Japanese using the Gemini API.

Read IMAGE_TRANSLATION.md in the skill directory for the FULL specification.

Setup:
1. Install: pip install google-genai Pillow
2. Gemini API key location: read IMAGE_TRANSLATION.md for the env file path
   Load the key before running any translation commands.

Tasks:
1. Read {OUTPUT_DIR}/image-map.json to identify images with English UI text
2. Skip these image types (do NOT translate):
   - Hardware photos (no translatable text)
   - Decorative images (is_decorative: true)
   - Diagrams with only labels/numbers
3. Translate these image groups using translate_images.py:
   - phone-screenshots: Mobile UI screenshots with English menus/labels
   - desktop-screenshots: Desktop/wide UI screenshots with English text
   Run for each applicable group:
   python scripts/translate_images.py {OUTPUT_DIR} --group phone-screenshots
   python scripts/translate_images.py {OUTPUT_DIR} --group desktop-screenshots
4. For each translated image (output: *_ja.png):
   - Update the corresponding <img src> in {OUTPUT_DIR}/index.html to point to the _ja.png version
   - Keep the original image as fallback (do not delete originals)

File ownership: You may ONLY write to:
- {OUTPUT_DIR}/images/*_ja.png (new translated images)
- {OUTPUT_DIR}/index.html (only <img src> attribute updates for translated images)

When complete, message lead:
"Image translation complete. Translated: {N} images. Updated img src references in index.html."
```

### qa-reviewer spawn prompt

Spawn ONLY after image-translator signals completion. Fresh context = unbiased review.

```
You are the qa-reviewer agent. Your task:

1. Install: pip install pymupdf beautifulsoup4
2. Run: python scripts/qa_verify.py {PDF_FILENAME} {OUTPUT_DIR}
3. Review the generated qa-report.md
4. Perform additional manual checks:

   Translation quality:
   - Terminology consistency (same English term → same Japanese term)
   - Product names unchanged from source
   - Menu paths in English（日本語）format
   - No missing sections (compare PDF TOC vs HTML sections)

   HTML structure:
   - All section IDs present and unique
   - TOC links work (checked by script)
   - Tables render correctly
   - Mobile responsiveness

   v3 layout (new checks):
   - Google Fonts link tags present in <head>
   - Noto Sans JP and Inter loading correctly
   - Figure classes applied (fig-cover, fig-hardware, fig-phone, fig-desktop)
   - Figure sizing appropriate for each class
   - CSS section counter working on h2 elements
   - Back-to-top button present and functional (JS included)
   - style.css is the v3 version (not v1 base)

   Image placement (highest priority):
   - Focus on data-placement-check="true" figures
   - Verify table-embedded images
   - Check side-by-side screenshot ordering
   - Verify grid layout image sequences

   Translated screenshots (new checks):
   - *_ja.png files exist for applicable screenshots
   - <img src> points to _ja.png versions where available
   - Japanese text in translated screenshots is readable
   - Original images preserved as fallback

5. Update qa-report.md with manual findings
6. List recommended fixes in priority order

File ownership: You may ONLY write to {OUTPUT_DIR}/qa-report.md

When complete, message lead:
"QA complete. Report: qa-report.md. Recommended fixes: {N}"
```

## CLAUDE.md recommended additions

Add to your project's `.claude/CLAUDE.md`:

```markdown
## PDF Manual Translation Project (v3)

### File ownership (MUST NOT VIOLATE)
| Agent | Files |
|---|---|
| image-extractor | {OUTPUT_DIR}/images/*, image-map.json |
| translator-html | index.html |
| layout-improver | style.css, index.html (class attrs + head only) |
| image-translator | images/*_ja.png, index.html (img src only) |
| qa-reviewer | qa-report.md |

Multiple agents editing the same file causes silent overwrites.

### Routing rules
- Phase 1+2: image-extractor and translator-html start in parallel
- Phase 3: layout-improver starts AFTER Phase 2 completes
- Phase 4: image-translator starts AFTER Phase 3 completes
- Phase 5: qa-reviewer spawned AFTER Phase 4 (Writer/Reviewer pattern, fresh context)
- Image placement in HTML depends on image-map.json completion
```
