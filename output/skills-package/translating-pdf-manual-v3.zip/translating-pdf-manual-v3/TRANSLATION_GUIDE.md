# Translation Guide

## Document type: Product manual / User guide

### Style rules

- Polite form: です・ます throughout
- Procedure steps: numbered (1. 2. 3.)
- Warning labels: 「危険」「警告」「注意」 (JIS Z 9101 aligned)
- Sentence length: 40 characters max per sentence
- Active voice preferred over passive
- No machine-translation tone; natural Japanese
- Product names, model numbers, brand names: unchanged from source
- Menu paths: English with Japanese in parentheses
  - Example: Settings（設定）→ Audio（オーディオ）→ Gain（ゲイン）

### Terminology table (core)

| English | 日本語 | Notes |
|---------|--------|-------|
| headphone out | ヘッドホン出力 | |
| line out | ライン出力 | |
| balanced | バランス | |
| single-ended | シングルエンド | |
| gain | ゲイン | |
| sample rate | サンプリングレート | |
| bit depth | ビット深度 | |
| firmware | ファームウェア | |
| firmware update | ファームウェアアップデート | |
| Bluetooth codec | Bluetoothコーデック | |
| DAC | DAC | First occurrence: 「D/Aコンバーター（DAC）」 |
| USB DAC | USB DAC | Keep as-is |
| amplifier | アンプ | |
| SPDIF | S/PDIF | |
| coaxial | 同軸（コアキシャル） | First: both forms. After: 「同軸」 |
| optical | 光（オプティカル） | First: both forms. After: 「光」 |
| equalizer | イコライザー | |
| channel balance | チャンネルバランス | |
| power adapter | 電源アダプター | |
| fast charging | 急速充電 | |
| factory reset | 工場出荷時リセット | |
| impedance | インピーダンス | Not 「抵抗」 |
| frequency response | 周波数特性 | |
| signal-to-noise ratio / S/N ratio | SN比 | Not 「信号対雑音比」 |
| THD | 全高調波歪率 / THD | Context-dependent |
| output power | 出力 | |
| input | 入力 | |
| volume | 音量 | |
| mute | ミュート | |
| standby | スタンバイ | |
| power on/off | 電源オン/オフ | |
| pairing | ペアリング | |
| streaming | ストリーミング | |
| playlist | プレイリスト | |
| shuffle | シャッフル | |
| repeat | リピート | |
| gapless playback | ギャップレス再生 | |
| lossless | ロスレス | |
| hi-res / high-resolution | ハイレゾ | |

For extended audio terminology, see [references/audio_terminology.md](references/audio_terminology.md).

### Terminology handling rules

When encountering a term NOT in the table:

1. Industry-standard katakana exists → Use it (e.g., ストリーミング)
2. Technical term, appears repeatedly → First occurrence with explanation, then abbreviation
3. Technical term, appears once → Contextual paraphrase
4. Uncertain → Keep English as-is

### Natural Japanese writing techniques

These rules prevent machine-translation tone:

**Sentence structure**
- Split long English sentences into 2-3 short Japanese sentences
- Convert passive voice: "can be connected" → 「接続します」
- Convert nominalization: "The connection of..." → 「接続すると...」

**Readability**
- Mix short and long sentences for rhythm
- Use concrete words: "ノイズレベルが高い" → 「うるさい」
- Avoid over-polite padding: 「〜ということが言えます」→「〜です」

**Warning/caution boxes**
- 「危険」: Risk of death or serious injury (red)
- 「警告」: Risk of injury or equipment damage (orange)
- 「注意」: Risk of minor issue or suboptimal result (yellow)
- Format: Bold label followed by concise instruction

### Quality checklist (post-translation)

Run through these checks after translating each section:

- [ ] Terminology consistency: same English term → same Japanese term throughout
- [ ] Product names unchanged from source
- [ ] Menu paths in English（日本語）format
- [ ] Numbers and units accurate
- [ ] No missing sections (compare against PDF TOC)
- [ ] Natural Japanese flow (read aloud test)
- [ ] Warning labels properly classified
