---
name: translating-pdf-manual
description: Translates English PDF product manuals into Japanese responsive HTML with images. Produces a fully localized v3 output with modern layout (Google Fonts, image sizing, section numbering) and AI-translated UI screenshots (Nano Banana Pro). Use when converting PDF manuals to Japanese HTML.
---

# PDF Manual to Japanese HTML Translation

English PDF product manuals to Japanese responsive HTML with extracted images, modern layout, and AI-translated screenshots.

## Quick start

### Single-agent workflow

1. Install dependencies:
   ```bash
   pip install pymupdf Pillow beautifulsoup4 google-genai
   ```

2. Extract images from PDF:
   ```bash
   python scripts/extract_images.py <pdf_file> <output_dir>
   ```

3. Translate PDF text and build HTML using [TRANSLATION_GUIDE.md](TRANSLATION_GUIDE.md) and [HTML_SPEC.md](HTML_SPEC.md)

4. Place images using `image-map.json` output from step 2

5. Apply v3 layout improvements following [LAYOUT_SPEC.md](LAYOUT_SPEC.md):
   - Add Google Fonts link tags
   - Apply figure classification (fig-cover / fig-hardware / fig-phone / fig-desktop)
   - Add section counter CSS
   - Add back-to-top button

6. Translate English text in screenshots to Japanese:
   ```bash
   python scripts/translate_images.py <output_dir> --group <group_name>
   ```
   See [IMAGE_TRANSLATION.md](IMAGE_TRANSLATION.md) for group definitions and API setup.

7. Validate with QA script:
   ```bash
   python scripts/qa_verify.py <pdf_file> <output_dir>
   ```

### Agent Teams workflow (recommended for large manuals)

For manuals over 20 pages, use Agent Teams for parallel processing.
See [AGENT_TEAMS.md](AGENT_TEAMS.md) for full orchestration guide.

Team structure: 5 agents across 5 phases with strict file ownership separation.

| Agent | Phase | Role | Owned files |
|---|---|---|---|
| image-extractor | 1 | Image extraction + mapping | images/*, image-map.json |
| translator-html | 2 | Translation + HTML build | index.html |
| layout-improver | 3 | Modern CSS + layout enhancement | style.css, index.html (class attrs only) |
| image-translator | 4 | Screenshot text translation | images/* (translated only) |
| qa-reviewer | 5 | Verification | qa-report.md |

## Configuration

Set these variables per product before starting:

```
PRODUCT_NAME  = "Product Name"        # e.g. "FiiO M27"
PDF_FILENAME  = "manual.pdf"          # PDF in working directory
OUTPUT_DIR    = "./output/manual-ja"  # Output path
BRAND_NAME    = "Brand"               # e.g. "FiiO"
GEMINI_API_KEY                        # From env file (see IMAGE_TRANSLATION.md)
```

The `GEMINI_API_KEY` is read from an environment file. See [IMAGE_TRANSLATION.md](IMAGE_TRANSLATION.md) for the exact location and setup.

## Output structure

```
{OUTPUT_DIR}/
├── index.html       # Translated HTML manual (v3: with Google Fonts, figure classes, back-to-top)
├── style.css        # Modern CSS (v3: Google Fonts, figure sizing, section counter)
├── images/          # Extracted images from PDF (v3: screenshots have Japanese text)
│   ├── page3_img1.png
│   ├── page3_img1_ja.png   ← AI-translated version
│   └── ...
├── image-map.json   # Image metadata and placement info
└── qa-report.md     # QA verification report
```

## 5-Phase workflow

### Phase 1: Image extraction

Run `extract_images.py` to extract all images from the PDF.

```bash
python scripts/extract_images.py {PDF_FILENAME} {OUTPUT_DIR}
```

Outputs:
- `{OUTPUT_DIR}/images/` — all extracted images
- `{OUTPUT_DIR}/image-map.json` — metadata with page numbers, coordinates, dimensions, confidence levels, and nearby headings

Review `image-map.json` and fill in `context_hint` for each image (what the image shows and which section it belongs to).

### Phase 2: Text translation + HTML build

1. Read the PDF and identify section structure from TOC or heading styles
2. Translate English to Japanese following [TRANSLATION_GUIDE.md](TRANSLATION_GUIDE.md)
3. Build responsive HTML following [HTML_SPEC.md](HTML_SPEC.md)
4. Place images using `image-map.json` with Japanese alt text and figcaption

Key translation rules:
- Style: です・ます (polite form)
- Product names unchanged
- Menu paths: English（日本語）format
- Sentences under 40 characters
- Natural Japanese, not machine-translation tone

### Phase 3: Layout improvement

Apply modern layout enhancements following [LAYOUT_SPEC.md](LAYOUT_SPEC.md):

1. **Google Fonts**: Add `<link>` tags for Noto Sans JP and Inter to `<head>`
2. **Figure classification**: Add CSS classes based on image dimensions from `image-map.json`:
   - `fig-cover` — full-width cover/hero images
   - `fig-hardware` — hardware diagrams and photos
   - `fig-phone` — phone/mobile screenshots (narrow, tall)
   - `fig-desktop` — desktop/wide UI screenshots
3. **Modern CSS**: Replace `style.css` with v3 version from `templates/style.css`
4. **Section counter**: CSS counter for automatic section numbering on h2 elements
5. **Back-to-top button**: Fixed button + JS added before `</body>`

### Phase 4: Image text translation

Translate English text visible in screenshots to Japanese using the Gemini API (Nano Banana Pro model).

```bash
python scripts/translate_images.py {OUTPUT_DIR} --group phone-screenshots
python scripts/translate_images.py {OUTPUT_DIR} --group desktop-screenshots
```

See [IMAGE_TRANSLATION.md](IMAGE_TRANSLATION.md) for:
- Which image groups to translate vs skip
- API key setup
- Group definitions and arguments
- Output naming convention (`*_ja.png`)
- HTML `<img src>` update after translation

### Phase 5: QA verification

```bash
python scripts/qa_verify.py {PDF_FILENAME} {OUTPUT_DIR}
```

Automated checks:
- Image count match (PDF vs output)
- Missing images
- Broken TOC links
- Missing alt text / figcaption

Manual checks:
- Translation quality and terminology consistency
- Figure classification correctness
- Google Fonts rendering
- Back-to-top button functionality
- Translated screenshot readability
- Mobile responsiveness

## Available scripts

All scripts in `scripts/` directory. Run with `python scripts/<name>.py`.

| Script | Purpose | Usage |
|---|---|---|
| extract_images.py | Extract all images from PDF with metadata | `python scripts/extract_images.py <pdf> <outdir>` |
| translate_images.py | Translate English text in screenshots to Japanese via Gemini API | `python scripts/translate_images.py <outdir> --group <group>` |
| qa_verify.py | Cross-verify PDF vs HTML: images, links, structure, translated images | `python scripts/qa_verify.py <pdf> <outdir>` |

## Key references

| File | Content | When to read |
|---|---|---|
| [TRANSLATION_GUIDE.md](TRANSLATION_GUIDE.md) | Translation rules, terminology table, style guidelines | Before translating |
| [HTML_SPEC.md](HTML_SPEC.md) | HTML template, CSS specs, image placement rules | When building HTML |
| [LAYOUT_SPEC.md](LAYOUT_SPEC.md) | v3 layout enhancements: Google Fonts, figure classes, section counter, back-to-top | When improving layout (Phase 3) |
| [IMAGE_TRANSLATION.md](IMAGE_TRANSLATION.md) | Screenshot translation: Gemini API setup, image groups, translate_images.py usage | When translating images (Phase 4) |
| [AGENT_TEAMS.md](AGENT_TEAMS.md) | Agent Teams orchestration, spawn prompts, file ownership | When using parallel agents |
| [references/audio_terminology.md](references/audio_terminology.md) | Extended audio equipment terminology dictionary | When translating audio-specific terms |

## Dependencies

```
pymupdf          # PDF parsing and image extraction
Pillow           # Image processing
beautifulsoup4   # HTML parsing for QA verification
google-genai     # Gemini API client for image text translation
```

Install all:
```bash
pip install pymupdf Pillow beautifulsoup4 google-genai
```
