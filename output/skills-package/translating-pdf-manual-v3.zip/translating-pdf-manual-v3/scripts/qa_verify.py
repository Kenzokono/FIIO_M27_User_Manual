#!/usr/bin/env python3
"""QA verification: cross-check PDF source against generated HTML.

Usage:
    python qa_verify.py <pdf_path> <output_dir>

Checks:
    - Image count: PDF vs image-map.json vs HTML figures
    - Missing images in HTML
    - Broken TOC anchor links
    - Missing alt text / figcaption
    - Low-confidence placements flagged

Output:
    {output_dir}/qa-report.md
"""

import sys
import os
import json
from datetime import datetime


def check_dependencies():
    missing = []
    try:
        import fitz
    except ImportError:
        missing.append("pymupdf")
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        missing.append("beautifulsoup4")
    if missing:
        print(f"Missing packages: {', '.join(missing)}")
        print(f"Install with: pip install {' '.join(missing)}")
        sys.exit(1)


def count_pdf_images(pdf_path):
    """Count images per page in PDF."""
    import fitz
    doc = fitz.open(pdf_path)
    total = 0
    page_counts = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        count = len(page.get_images(full=True))
        page_counts.append({"page": page_num + 1, "count": count})
        total += count
    doc.close()
    return total, page_counts


def parse_html(output_dir):
    """Parse HTML and extract image/structure info."""
    from bs4 import BeautifulSoup

    html_path = os.path.join(output_dir, "index.html")
    if not os.path.isfile(html_path):
        return None, "index.html not found"

    with open(html_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f.read(), "html.parser")

    # Collect figures
    figures = []
    for fig in soup.find_all("figure"):
        img = fig.find("img")
        if not img:
            continue
        parent = fig.find_parent("section")
        section_id = parent.get("id", "unknown") if parent else "unknown"
        h = parent.find(["h2", "h3"]) if parent else None
        heading = h.get_text(strip=True) if h else "unknown"

        figures.append({
            "src": img.get("src", ""),
            "alt": img.get("alt", ""),
            "section_id": section_id,
            "section_heading": heading,
            "has_figcaption": fig.find("figcaption") is not None,
            "needs_check": img.get("data-placement-check") == "true"
                           or fig.get("data-placement-check") == "true",
        })

    # Collect standalone <img> not in <figure>
    standalone_imgs = []
    for img in soup.find_all("img"):
        if not img.find_parent("figure"):
            standalone_imgs.append({
                "src": img.get("src", ""),
                "alt": img.get("alt", ""),
            })

    # Check TOC links
    toc = soup.find("nav", id="toc")
    toc_results = []
    if toc:
        for link in toc.find_all("a", href=True):
            href = link["href"]
            if href.startswith("#"):
                target = soup.find(id=href[1:])
                toc_results.append({
                    "href": href,
                    "text": link.get_text(strip=True),
                    "valid": target is not None,
                })
    else:
        toc_results = None

    # Count sections
    sections = soup.find_all("section")
    section_ids = [s.get("id", "") for s in sections]

    return {
        "figures": figures,
        "standalone_imgs": standalone_imgs,
        "toc_results": toc_results,
        "section_ids": section_ids,
    }, None


def generate_report(pdf_path, output_dir):
    """Run all checks and write qa-report.md."""
    report = []
    report.append("# QA検証レポート\n")
    report.append(f"検証日時: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"検証対象PDF: {pdf_path}")
    report.append(f"出力ディレクトリ: {output_dir}\n")

    issues = []

    # 1. Image counts
    pdf_total, _ = count_pdf_images(pdf_path)

    map_path = os.path.join(output_dir, "image-map.json")
    if os.path.isfile(map_path):
        with open(map_path, "r", encoding="utf-8") as f:
            image_map = json.load(f)
        map_total = len(image_map)
        decorative = sum(1 for i in image_map if i.get("is_decorative"))
        low_conf = sum(1 for i in image_map if i.get("placement_confidence") == "low")
    else:
        image_map = []
        map_total = 0
        decorative = 0
        low_conf = 0
        issues.append("[CRITICAL] image-map.json が見つかりません")

    html_data, html_err = parse_html(output_dir)
    if html_err:
        issues.append(f"[CRITICAL] {html_err}")
        html_figures = 0
    else:
        html_figures = len(html_data["figures"])

    report.append("## 1. 概要\n")
    report.append(f"| 項目 | 数 |")
    report.append(f"|---|---|")
    report.append(f"| PDF内画像数 | {pdf_total} |")
    report.append(f"| image-map.json登録数 | {map_total} |")
    report.append(f"| HTML内figure数 | {html_figures} |")
    report.append(f"| 装飾画像 | {decorative} |")
    report.append(f"| 配置不確実 | {low_conf} |")
    report.append("")

    content_images = map_total - decorative
    if content_images != html_figures:
        issues.append(
            f"[WARNING] コンテンツ画像数不一致: image-map={content_images} (装飾除外), HTML figures={html_figures}"
        )

    # 2. Per-image placement check
    if html_data and image_map:
        report.append("## 2. 画像配置チェック\n")
        ok_count = 0
        missing_count = 0
        check_count = 0

        for entry in image_map:
            fn = entry["filename"]
            if entry.get("is_decorative"):
                continue

            matches = [f for f in html_data["figures"] if fn in f.get("src", "")]
            if not matches:
                report.append(f"- [未配置] {fn} (PDF p.{entry['page']})")
                missing_count += 1
            else:
                m = matches[0]
                if m.get("needs_check"):
                    report.append(f"- [要確認] {fn} → {m['section_heading']}")
                    check_count += 1
                else:
                    ok_count += 1

                if not m.get("alt"):
                    report.append(f"  - alt テキストなし: {fn}")
                    issues.append(f"[MINOR] alt属性なし: {fn}")
                if not m.get("has_figcaption"):
                    report.append(f"  - figcaption なし: {fn}")
                    issues.append(f"[MINOR] figcaptionなし: {fn}")

        report.append(f"\n正常: {ok_count} / 要確認: {check_count} / 未配置: {missing_count}\n")

        if missing_count > 0:
            issues.append(f"[ERROR] 未配置画像: {missing_count}枚")

    # 3. TOC link check
    if html_data and html_data["toc_results"] is not None:
        report.append("## 3. 目次リンクチェック\n")
        broken = [t for t in html_data["toc_results"] if not t["valid"]]
        if broken:
            for b in broken:
                report.append(f"- [リンク切れ] {b['href']} → {b['text']}")
            issues.append(f"[ERROR] 目次リンク切れ: {len(broken)}件")
        else:
            report.append(f"全{len(html_data['toc_results'])}リンク正常\n")
    elif html_data and html_data["toc_results"] is None:
        report.append("## 3. 目次リンクチェック\n")
        report.append("nav#toc が見つかりません\n")
        issues.append("[WARNING] nav#toc が存在しません")

    # 4. Standalone images (not in figure)
    if html_data and html_data["standalone_imgs"]:
        report.append("## 4. figure外の画像\n")
        for si in html_data["standalone_imgs"]:
            report.append(f"- {si['src']} (alt: {si['alt'] or 'なし'})")
        report.append("")

    # 5. Issues summary
    report.append("## 修正推奨事項（優先度順）\n")
    if issues:
        critical = [i for i in issues if i.startswith("[CRITICAL]")]
        errors = [i for i in issues if i.startswith("[ERROR]")]
        warnings = [i for i in issues if i.startswith("[WARNING]")]
        minor = [i for i in issues if i.startswith("[MINOR]")]

        priority = 1
        for group in [critical, errors, warnings, minor]:
            for item in group:
                report.append(f"{priority}. {item}")
                priority += 1
    else:
        report.append("問題なし")

    # Write report
    report_path = os.path.join(output_dir, "qa-report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report))

    print(f"QA report: {report_path}")
    print(f"  Issues found: {len(issues)}")
    return len(issues)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python qa_verify.py <pdf_path> <output_dir>")
        print("  pdf_path   : Path to source PDF")
        print("  output_dir : Directory containing index.html, image-map.json, images/")
        sys.exit(1)

    check_dependencies()
    issue_count = generate_report(sys.argv[1], sys.argv[2])
    sys.exit(1 if issue_count > 0 else 0)
