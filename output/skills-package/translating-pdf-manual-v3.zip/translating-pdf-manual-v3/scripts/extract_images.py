#!/usr/bin/env python3
"""Extract all images from a PDF and generate image-map.json.

Usage:
    python extract_images.py <pdf_path> <output_dir>

Output:
    - {output_dir}/images/  : extracted image files
    - {output_dir}/image-map.json : metadata for each image
"""

import sys
import os
import json

def check_dependencies():
    """Verify required packages are installed."""
    missing = []
    try:
        import fitz
    except ImportError:
        missing.append("pymupdf")
    try:
        from PIL import Image
    except ImportError:
        missing.append("Pillow")
    if missing:
        print(f"Missing packages: {', '.join(missing)}")
        print(f"Install with: pip install {' '.join(missing)}")
        sys.exit(1)

def extract_images(pdf_path, output_dir):
    """Extract images from PDF and generate image-map.json."""
    import fitz
    from PIL import Image
    import io

    if not os.path.isfile(pdf_path):
        print(f"Error: PDF not found: {pdf_path}")
        sys.exit(1)

    images_dir = os.path.join(output_dir, "images")
    os.makedirs(images_dir, exist_ok=True)

    doc = fitz.open(pdf_path)
    image_map = []
    stats = {"total": 0, "decorative": 0, "low_confidence": 0, "errors": 0}

    for page_num in range(len(doc)):
        page = doc[page_num]
        image_list = page.get_images(full=True)

        for img_idx, img in enumerate(image_list):
            xref = img[0]
            try:
                base_image = doc.extract_image(xref)
            except Exception as e:
                print(f"  Warning: Failed to extract xref {xref} on page {page_num + 1}: {e}")
                stats["errors"] += 1
                continue

            image_bytes = base_image["image"]
            image_ext = base_image["ext"]
            width = base_image.get("width", 0)
            height = base_image.get("height", 0)

            # Skip truly empty images
            if len(image_bytes) < 100:
                continue

            filename = f"page{page_num + 1}_img{img_idx + 1}.{image_ext}"
            filepath = os.path.join(images_dir, filename)

            with open(filepath, "wb") as f:
                f.write(image_bytes)

            # Position info (may be inaccurate for complex layouts)
            rect_info = None
            placement_confidence = "high"
            try:
                img_rects = page.get_image_rects(xref)
                if img_rects:
                    rect = img_rects[0]
                    rect_info = {
                        "x0": round(rect.x0, 1),
                        "y0": round(rect.y0, 1),
                        "x1": round(rect.x1, 1),
                        "y1": round(rect.y1, 1)
                    }
                else:
                    placement_confidence = "low"
                    stats["low_confidence"] += 1
            except Exception:
                placement_confidence = "low"
                stats["low_confidence"] += 1

            # Extract nearby headings from page text
            page_text = page.get_text("text")
            lines = [l.strip() for l in page_text.split("\n") if l.strip()]
            headings = lines[:5] if lines else []

            # Decorative image detection
            is_decorative = (width < 32 and height < 32)
            if is_decorative:
                stats["decorative"] += 1

            image_map.append({
                "filename": filename,
                "page": page_num + 1,
                "rect": rect_info,
                "placement_confidence": placement_confidence,
                "context_hint": "",
                "nearby_headings": headings,
                "image_width": width,
                "image_height": height,
                "is_decorative": is_decorative
            })
            stats["total"] += 1

    doc.close()

    # Write image-map.json
    map_path = os.path.join(output_dir, "image-map.json")
    with open(map_path, "w", encoding="utf-8") as f:
        json.dump(image_map, f, ensure_ascii=False, indent=2)

    # Summary
    print(f"Extraction complete: {map_path}")
    print(f"  Total images: {stats['total']}")
    print(f"  Decorative (< 32x32): {stats['decorative']}")
    print(f"  Low confidence placement: {stats['low_confidence']}")
    if stats["errors"] > 0:
        print(f"  Extraction errors: {stats['errors']}")
    print(f"  Images saved to: {images_dir}")

    return stats

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_images.py <pdf_path> <output_dir>")
        print("  pdf_path   : Path to English PDF manual")
        print("  output_dir : Output directory (will be created)")
        sys.exit(1)

    check_dependencies()
    extract_images(sys.argv[1], sys.argv[2])
