#!/usr/bin/env python3
"""
Product Manual Image Translator
Uses Gemini (Nano Banana Pro) API to translate English text in images to Japanese.

Usage:
    python translate_images.py <images_dir> [--api-key KEY] [--api-key-file FILE]
                               [--product-name NAME] [--hardware FILENAME]
                               [--skip FILENAME ...] [--group a|b|all]

Arguments:
    images_dir          Directory containing images to translate

Options:
    --api-key KEY       Gemini API key (or set GEMINI_API_KEY env var)
    --api-key-file FILE File containing API key (format: GEMINI_API_KEY=xxx)
    --product-name NAME Product name for prompts (default: "Product")
    --hardware FILENAME Image file to treat as hardware diagram (different prompt)
    --skip FILENAME     Image files to skip (can be repeated)
    --group a|b|all     Process group A (first half), B (second half), or all
"""

import sys
import os
import time
import json
import argparse
from io import BytesIO
from pathlib import Path

from google import genai
from google.genai import types
from PIL import Image

PRIMARY_MODEL = "gemini-3-pro-image-preview"
FALLBACK_MODEL = "gemini-2.5-flash-image"


def get_prompts(product_name):
    """Generate translation prompts with product name."""
    ui_prompt = f"""この画像は{product_name}のスクリーンショットです。
画像内の英語テキストを全て対応する日本語に翻訳してください。
中国語テキストがある場合はそのまま残してください。
テキスト以外の要素（背景、アイコン、レイアウト、色、UI部品の配置）は一切変更しないでください。
画像の解像度とアスペクト比も元のまま維持してください。
翻訳のみを行い、画像を再構成しないでください。"""

    hw_prompt = f"""この画像は{product_name}の各部名称図（ボタン・端子の説明図）です。
ラベルの英語テキストを全て対応する日本語に翻訳してください。
中国語テキストがある場合はそのまま残してください。
図のレイアウト、線、矢印、製品画像は一切変更しないでください。
テキストのフォントサイズと配置は元のまま維持してください。
翻訳のみを行い、画像を再構成しないでください。"""

    return ui_prompt, hw_prompt


def load_api_key(args):
    """Load API key from args, file, or environment."""
    if args.api_key:
        return args.api_key
    if args.api_key_file:
        with open(args.api_key_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("GEMINI_API_KEY"):
                    return line.split("=", 1)[1].strip()
    return os.environ.get("GEMINI_API_KEY")


def get_translatable_images(images_dir, skip_files):
    """Get list of image files to translate, excluding skipped files."""
    skip_set = set(skip_files)
    images = []
    for f in sorted(images_dir.iterdir()):
        if f.suffix.lower() in (".jpeg", ".jpg", ".png") and f.name not in skip_set:
            images.append(f.name)
    return images


def translate_image(client, images_dir, filename, ui_prompt, hw_prompt,
                    hardware_files, model=PRIMARY_MODEL, max_retries=3):
    """Translate English text in a single image to Japanese."""
    filepath = images_dir / filename
    if not filepath.exists():
        print(f"  SKIP: {filename} not found")
        return False

    prompt = hw_prompt if filename in hardware_files else ui_prompt
    image = Image.open(filepath)
    original_size = image.size

    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(
                model=model,
                contents=[prompt, image],
                config=types.GenerateContentConfig(
                    response_modalities=["Text", "Image"]
                ),
            )

            for part in response.candidates[0].content.parts:
                if part.inline_data is not None:
                    result = Image.open(BytesIO(part.inline_data.data))
                    if result.mode == "RGBA":
                        result = result.convert("RGB")
                    result.save(filepath, "JPEG", quality=95)
                    new_size = result.size
                    print(f"  OK: {filename} ({original_size} -> {new_size})")
                    return True

            print(f"  WARN: {filename} - no image in response (attempt {attempt+1})")

        except Exception as e:
            error_str = str(e)
            if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str:
                wait = 30 * (attempt + 1)
                print(f"  RATE LIMIT: {filename} - waiting {wait}s (attempt {attempt+1})")
                time.sleep(wait)
            elif "400" in error_str or "INVALID_ARGUMENT" in error_str:
                if model == PRIMARY_MODEL:
                    print(f"  FALLBACK: {filename} - trying {FALLBACK_MODEL}")
                    return translate_image(client, images_dir, filename,
                                           ui_prompt, hw_prompt, hardware_files,
                                           model=FALLBACK_MODEL)
                else:
                    print(f"  FAIL: {filename} - {error_str[:100]}")
                    return False
            else:
                print(f"  ERROR: {filename} - {error_str[:100]} (attempt {attempt+1})")
                if attempt < max_retries - 1:
                    time.sleep(5)

    print(f"  FAIL: {filename} - max retries exceeded")
    return False


def main():
    parser = argparse.ArgumentParser(description="Translate English text in images to Japanese")
    parser.add_argument("images_dir", help="Directory containing images")
    parser.add_argument("--api-key", help="Gemini API key")
    parser.add_argument("--api-key-file", help="File containing GEMINI_API_KEY=xxx")
    parser.add_argument("--product-name", default="Product", help="Product name for prompts")
    parser.add_argument("--hardware", action="append", default=[], help="Hardware diagram file(s)")
    parser.add_argument("--skip", action="append", default=[], help="Files to skip")
    parser.add_argument("--group", choices=["a", "b", "all"], default="all",
                        help="Process first half (a), second half (b), or all")
    args = parser.parse_args()

    images_dir = Path(args.images_dir)
    if not images_dir.exists():
        print(f"Error: {images_dir} does not exist")
        return 1

    api_key = load_api_key(args)
    if not api_key:
        print("Error: No API key. Use --api-key, --api-key-file, or GEMINI_API_KEY env var")
        return 1

    ui_prompt, hw_prompt = get_prompts(args.product_name)
    hardware_files = set(args.hardware)

    images = get_translatable_images(images_dir, args.skip)

    # Split into groups if requested
    mid = len(images) // 2
    if args.group == "a":
        images = images[:mid]
    elif args.group == "b":
        images = images[mid:]

    print(f"=== Image Translator ===")
    print(f"Product: {args.product_name}")
    print(f"Group: {args.group} ({len(images)} images)")
    print(f"Model: {PRIMARY_MODEL}")
    print(f"Output: {images_dir}")
    print()

    client = genai.Client(api_key=api_key)
    results = {"success": [], "failed": []}

    for i, filename in enumerate(images, 1):
        print(f"[{i}/{len(images)}] Processing {filename}...")
        success = translate_image(client, images_dir, filename,
                                   ui_prompt, hw_prompt, hardware_files)
        if success:
            results["success"].append(filename)
        else:
            results["failed"].append(filename)
        if i < len(images):
            time.sleep(3)

    print()
    print(f"=== Results ===")
    print(f"Success: {len(results['success'])}/{len(images)}")
    print(f"Failed:  {len(results['failed'])}/{len(images)}")
    if results["failed"]:
        print(f"Failed files: {', '.join(results['failed'])}")

    results_file = images_dir.parent / "translation-results.json"
    with open(results_file, "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"Results saved to: {results_file}")

    return 0 if not results["failed"] else 1


if __name__ == "__main__":
    sys.exit(main())
