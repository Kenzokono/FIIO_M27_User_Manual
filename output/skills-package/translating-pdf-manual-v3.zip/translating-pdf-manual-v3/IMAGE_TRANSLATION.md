# IMAGE_TRANSLATION.md — v3 画像内テキスト翻訳仕様書

Nano Banana Pro（Gemini 3 Pro Image）を使用して、マニュアル画像内の英語テキストを日本語に翻訳する Phase 4 の仕様。

---

## 1. API 設定

### モデル

| 優先度 | モデル ID | 用途 |
|---|---|---|
| Primary | `gemini-3-pro-image-preview` | 画像生成・テキスト翻訳 |
| Fallback | `gemini-2.5-flash-image` | Primary 失敗時のフォールバック |

### パッケージ

```
google-genai
```

### API キー

環境設定で指定されたファイルパスから読み込む:

```python
# config.yaml 内の設定
GEMINI_API_KEY_FILE: "/path/to/api-key-file"

# 読み込み方法
with open(config["GEMINI_API_KEY_FILE"], "r") as f:
    api_key = f.read().strip()
```

---

## 2. 画像分類（翻訳対象の判定）

### 翻訳対象

英語 UI テキストを含む画像:
- DAP のメニュー・設定画面のスクリーンショット
- 操作説明の UI スクリーンショット
- 各部名称図（ハードウェアダイアグラム）のラベル

### 翻訳スキップ対象

以下の画像は翻訳処理をスキップする:

| スキップ条件 | 判定方法 |
|---|---|
| 製品カバー写真 | 最初の画像かつ正方形（アスペクト比 0.8〜1.2） |
| 装飾・テーマ画像 | `is_decorative: true` または `context_hint` に "theme" / "decorative" を含む |
| アルバムアート・カバー表示 | `context_hint` に "album" / "cover art" / "now playing" を含む |
| Windows/macOS システム UI | `context_hint` に "windows" / "macos" / "desktop app" を含む |
| テキストなし画像 | `has_text: false` または目視で文字なしと判定 |

---

## 3. プロンプト戦略

### UI スクリーンショット用プロンプト

```
この画像は{PRODUCT_NAME}デジタルオーディオプレーヤーのスクリーンショットです。
画像内の英語テキストを全て対応する日本語に翻訳してください。
中国語テキストがある場合はそのまま残してください。
テキスト以外の要素（背景、アイコン、レイアウト、色、UI部品の配置）は一切変更しないでください。
画像の解像度とアスペクト比も元のまま維持してください。
翻訳のみを行い、画像を再構成しないでください。
```

### ハードウェアダイアグラム用プロンプト

```
この画像は{PRODUCT_NAME}デジタルオーディオプレーヤーの各部名称図です。
ラベルの英語テキストを全て対応する日本語に翻訳してください。
中国語テキストがある場合はそのまま残してください。
図のレイアウト、線、矢印、製品画像は一切変更しないでください。
テキストのフォントサイズと配置は元のまま維持してください。
翻訳のみを行い、画像を再構成しないでください。
```

### プロンプト選択ロジック

```
if context_hint contains "diagram" or "parts" or "guide":
    → ハードウェアダイアグラム用プロンプトを使用
else:
    → UI スクリーンショット用プロンプトを使用
```

`{PRODUCT_NAME}` はプロジェクト設定（config.yaml の `product_name`）から動的に挿入する。

---

## 4. エラーハンドリング

### リトライ戦略

| エラーコード | エラー種別 | 対処 |
|---|---|---|
| 400 | `INVALID_ARGUMENT` | フォールバックモデル（`gemini-2.5-flash-image`）で再試行 |
| 429 | `RESOURCE_EXHAUSTED` | `30秒 × 試行回数` 待機後リトライ（最大3回） |
| その他 | 予期しないエラー | ログに記録し、元画像をそのまま使用 |

### リトライフロー

```
attempt = 1
model = primary_model

while attempt <= 3:
    try:
        result = call_api(model, image, prompt)
        return result
    except INVALID_ARGUMENT:
        if model == primary_model:
            model = fallback_model
            continue
        else:
            log_error("Both models failed")
            return original_image
    except RESOURCE_EXHAUSTED:
        wait(30 * attempt)
        attempt += 1
    except Exception as e:
        log_error(e)
        return original_image

return original_image  # All retries exhausted
```

### レート制限

- API 呼び出し間に **3秒** の遅延を挿入
- `time.sleep(3)` を各リクエスト後に実行

---

## 5. スクリプト使用方法

```bash
# 全翻訳対象画像を処理
python scripts/translate_images.py all

# グループ A のみ処理
python scripts/translate_images.py a

# グループ B のみ処理
python scripts/translate_images.py b

# 単一画像を処理
python scripts/translate_images.py <file>
```

### グループ分類

image-map.json の `group` フィールドに基づく:
- **Group A**: UI スクリーンショット（メニュー、設定画面等）
- **Group B**: ハードウェアダイアグラム（各部名称図等）

---

## 6. 出力仕様

### ファイル出力

| 項目 | 説明 |
|---|---|
| 翻訳済み画像 | 出力ディレクトリの `images/` 内に元ファイルを上書き |
| オリジナル保存 | 比較が必要な場合、別バージョンフォルダに保存 |
| 結果ログ | `translation-results.json` に処理結果を記録 |

### translation-results.json フォーマット

```json
{
  "timestamp": "2026-02-20T10:00:00Z",
  "product_name": "FiiO M27",
  "model_used": "gemini-3-pro-image-preview",
  "results": [
    {
      "file": "images/page3_img1.png",
      "status": "translated",
      "model": "gemini-3-pro-image-preview",
      "prompt_type": "ui_screenshot",
      "attempts": 1
    },
    {
      "file": "images/page5_img1.png",
      "status": "skipped",
      "reason": "decorative_image"
    },
    {
      "file": "images/page8_img1.png",
      "status": "error",
      "error": "Both models failed with INVALID_ARGUMENT",
      "kept_original": true
    }
  ],
  "summary": {
    "total": 45,
    "translated": 38,
    "skipped": 5,
    "errors": 2
  }
}
```

---

## 7. チェックリスト

Phase 4 実行時の確認事項:

- [ ] GEMINI_API_KEY_FILE が正しく設定されている
- [ ] Primary モデルへの接続テストが成功
- [ ] image-map.json の全画像が分類されている
- [ ] 翻訳スキップ対象が正しく除外されている
- [ ] 翻訳済み画像の解像度が元画像と一致している
- [ ] 中国語テキストが保持されている
- [ ] translation-results.json が正しく出力されている
- [ ] エラー発生時に元画像が保持されている
