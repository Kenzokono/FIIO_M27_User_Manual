# Audio Equipment Terminology Dictionary

Extended reference for audio-specific translation. Consult when translating hi-fi audio product manuals.

## Sound quality terms

| English | 日本語 | Context |
|---------|--------|---------|
| transparency | 透明感 | Sound clarity, openness |
| soundstage | 音場（おんじょう） | 「サウンドステージ」also acceptable |
| imaging | 定位 / 音像定位 | Spatial placement of sound |
| warm / warmth | 暖かみ / ウォーム | Tonal quality, not temperature |
| bright | ブライト / 明るい | High-frequency emphasis |
| dark | ダーク / 暗い | Reduced high frequencies |
| resolution | 解像度 | Detail retrieval. NOT 「解決」 |
| detail | ディテール / 細部 | Fine sonic information |
| dynamics | ダイナミクス | Volume contrast capability |
| transient | トランジェント | Attack speed of notes |
| sibilance | 歯擦音（しさつおん） | Harsh "s" sounds |
| distortion | 歪み（ひずみ） | |
| crosstalk | クロストーク / 漏話 | Channel separation issue |
| separation | セパレーション / 分離 | |
| coherence | コヒーレンス / 一体感 | |
| fatigue | 聴き疲れ | Listener fatigue |
| airiness | 空気感 | Sense of space in recording |
| texture | テクスチャー / 質感 | |
| timbre | 音色（ねいろ） | |
| coloration | 色付け | Unwanted tonal addition |
| neutral | ニュートラル / フラット | |

## Digital audio terms

| English | 日本語 | Context |
|---------|--------|---------|
| PCM | PCM | リニアPCM when specifying |
| DSD | DSD | Explain as 「1ビット方式」on first use if needed |
| MQA | MQA | Keep as-is |
| bit-perfect | ビットパーフェクト | Exact digital reproduction |
| upsampling | アップサンプリング | |
| oversampling | オーバーサンプリング | |
| jitter | ジッター | Clock timing error |
| clock | クロック | Digital timing reference |
| buffer | バッファ | |
| latency | レイテンシー / 遅延 | |
| ASIO | ASIO | Keep as-is |
| WASAPI | WASAPI | Keep as-is |
| ALSA | ALSA | Keep as-is |
| bit rate | ビットレート | |
| lossless | ロスレス | |
| lossy | ロッシー / 非可逆 | |
| codec | コーデック | |
| FLAC | FLAC | |
| ALAC | ALAC | |
| WAV | WAV | |
| AIFF | AIFF | |
| AAC | AAC | |
| aptX | aptX | Case-sensitive |
| aptX HD | aptX HD | |
| aptX Adaptive | aptX Adaptive | |
| LDAC | LDAC | |
| SBC | SBC | |
| LC3 | LC3 | |
| LE Audio | LE Audio | |

## Amplifier and power terms

| English | 日本語 | Context |
|---------|--------|---------|
| Class A | A級 | |
| Class AB | AB級 | |
| Class D | D級 | |
| headphone amplifier | ヘッドホンアンプ | |
| preamp / preamplifier | プリアンプ | |
| power amplifier | パワーアンプ | |
| integrated amplifier | プリメインアンプ | NOT 「統合アンプ」 |
| damping factor | ダンピングファクター | |
| output impedance | 出力インピーダンス | |
| input impedance | 入力インピーダンス | |
| gain | ゲイン | |
| THD / THD+N | 全高調波歪率 / THD | Context-dependent |
| S/N ratio | SN比 | NOT 「信号対雑音比」 |
| channel separation | チャンネルセパレーション | |
| power consumption | 消費電力 | |
| idle power | 待機電力 | |

## Connector and cable terms

| English | 日本語 | Context |
|---------|--------|---------|
| 3.5mm | 3.5mm | |
| 4.4mm balanced | 4.4mmバランス | Pentaconn |
| XLR | XLR | |
| RCA | RCA | |
| USB Type-C | USB Type-C | |
| USB-A | USB-A | |
| coaxial (digital) | 同軸デジタル | |
| optical / TOSLINK | 光デジタル / TOSLINK | |
| I2S | I2S | |
| AES/EBU | AES/EBU | |
| HDMI ARC | HDMI ARC | |
| HDMI eARC | HDMI eARC | |
| antenna | アンテナ | |
| TRS | TRS | |
| TRRS | TRRS | |

## Headphone and IEM terms

| English | 日本語 | Context |
|---------|--------|---------|
| over-ear | オーバーイヤー | |
| on-ear | オンイヤー | |
| in-ear monitor (IEM) | イヤモニ / IEM | |
| earbud | イヤーバッド | |
| TWS (true wireless) | 完全ワイヤレス / TWS | |
| noise cancelling (ANC) | ノイズキャンセリング | |
| ear tip | イヤーピース | |
| nozzle | ノズル | |
| driver | ドライバー | Audio transducer |
| dynamic driver | ダイナミックドライバー | |
| balanced armature | バランスド・アーマチュア / BA | |
| planar magnetic | 平面磁界駆動 / 平面磁気 | |
| electrostatic | 静電型 | |
| sensitivity | 感度 | dB/mW or dB/V |
| clamping force | 側圧 | |

## Streaming and playback terms

| English | 日本語 | Context |
|---------|--------|---------|
| streaming | ストリーミング | |
| DLNA | DLNA | |
| AirPlay | AirPlay | |
| Chromecast | Chromecast | |
| Roon Ready | Roon Ready | |
| UPnP | UPnP | |
| NAS | NAS | |
| music library | 音楽ライブラリ | |
| now playing | 再生中 | |
| queue | 再生キュー | |
| gapless playback | ギャップレス再生 | |
| crossfade | クロスフェード | |
| replay gain | リプレイゲイン | |
| metadata | メタデータ | |
| album art | アルバムアート | |
| tag | タグ | |

## Specification and measurement terms

| English | 日本語 | Context |
|---------|--------|---------|
| frequency response | 周波数特性 | |
| dynamic range | ダイナミックレンジ | |
| noise floor | ノイズフロア | |
| SINAD | SINAD | |
| output power | 出力 | W or mW with load impedance |
| dimensions | 外形寸法 | W x D x H |
| weight | 質量 | NOT 「重量」in specs |
| operating temperature | 動作温度 | |
| battery capacity | バッテリー容量 | mAh |
| battery life | バッテリー駆動時間 | |
| charging time | 充電時間 | |
